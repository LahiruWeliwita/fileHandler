package fileHandler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class readWrite {
	
	public String read(String fullPath) {
		String path=fullPath,fileContent="",fileName;
		System.out.println("enter file name to Read :");
		Scanner s =new Scanner(System.in);
		fileName=s.nextLine();
		try (BufferedReader in =new BufferedReader(new FileReader(path+"\\"+fileName+""))){
			String line;
			while((line=in.readLine())!=null) {
				//System.out.println(line);
				fileContent=fileContent.concat(line+"\n");
			  }System.out.println(fileContent);
			}
		 catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Oops,File Not Found!!");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			System.out.println("Oops,Somting was wrong!!");
			e1.printStackTrace();
		}
		return fileContent;
		
	}
public void write(String contentToWrite, String folder) {
	System.out.println("enter file name to save :");
	Scanner s =new Scanner(System.in);
	String fileName=s.nextLine();
		try {
			String fileFolder= folder;
			FileWriter writer = new FileWriter("D:\\Study\\fileHandler\\"+fileFolder+"\\"+fileName+"");
			writer.append(contentToWrite);
			System.out.println("data writen to the file");
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Oops,Somting is wrong!!");
			e.printStackTrace();
		}
		
	}
}
