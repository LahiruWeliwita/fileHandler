package fileHandler;

import java.util.Scanner;

public class file {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		selectFolder();
		
	}

public static void selectFolder() {
	Scanner s=new Scanner(System.in);
	String []folders = {"TextFiles","read","write"};	
	readWrite rw= new readWrite();
	System.out.println("select a number(1/2)");
	int i =s.nextInt();
	linux ln =new linux();
	if(i==1) {
		//reading form TextFiles and writing to read!!!!
		System.out.println("\n======================================================================\n");
		ln.runLinux("D:\\Study\\HDSE\\SS\\TxTEncryptor\\Files\\"+folders[0]+"");
		System.out.println("\n======================================================================\n");
		String content= rw.read("D:\\Study\\HDSE\\SS\\TxTEncryptor\\Files\\TextFiles");
		System.out.println("\n======================================================================\n");
		rw.write(content,folders[1]);
		System.out.println("\n======================================================================\n");
		ln.runLinux("D:\\Study\\fileHandler\\"+folders[1]+"");
		System.out.println("\n======================================================================\n");
		
	}else if(i==2) {
		//reading form read and writing to write!!!!
		ln.runLinux("D:\\Study\\fileHandler\\"+folders[1]+"");
		System.out.println("\n======================================================================\n");
		String content= rw.read(folders[1]);
		System.out.println("\n======================================================================\n");
		rw.write(content,folders[2]);	
		System.out.println("\n======================================================================\n");
		ln.runLinux("D:\\Study\\fileHandler\\"+folders[2]+"");
		System.out.println("\n======================================================================\n");
		}
	}

}
