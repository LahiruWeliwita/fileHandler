package fileHandler;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class linux {
	public void runLinux(String fullPath) {
		try {
			String path =fullPath;
			Process process = Runtime.getRuntime().exec(
					new String[]{"cmd", "/c", "dir"},
			        null, 
			        new File(path));
			StringBuilder output =new StringBuilder();
			BufferedReader reader =new BufferedReader(new InputStreamReader(process.getInputStream()));
			
			String line;
			while((line=reader.readLine())!= null) {
				output.append(line+"\n");
			}
			int exitVal=process.waitFor();
			if(exitVal==0) {
				System.out.println(output);
			}else {	System.out.println("Somthing is wrong!!!");}
			
		}
		catch (IOException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		catch (InterruptedException e1) {
			// TODO: handle exception
			e1.printStackTrace();
		}
	}
	}
